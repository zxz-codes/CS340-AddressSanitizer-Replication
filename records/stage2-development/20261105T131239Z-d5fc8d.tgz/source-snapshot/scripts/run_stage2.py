#!/usr/bin/env python3
"""Stage 2: separate raw streams, upstream lit checks, frozen fixed-work matrix."""
import argparse
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shlex
import shutil
import signal
import statistics
import subprocess
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
WORK = Path(os.environ.get('CS340_ASAN_WORKDIR', Path.home() / '.cache/cs340-asan'))
SOURCE = WORK / 'llvm-test-suite'
CONFIGS = ('native', 'asan-modern', 'asan-paper-like')


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stats(values):
    return {'mean': statistics.mean(values), 'sd': statistics.stdev(values), 'n': len(values)}


def summarize(rows):
    result = []
    for workload, config in sorted({(r['workload'], r['configuration']) for r in rows}):
        group = [r for r in rows if (r['workload'], r['configuration']) == (workload, config)]
        item = {'workload': workload, 'configuration': config}
        for metric in ('elapsed_seconds', 'max_rss_kib'):
            item[metric] = stats([r[metric] for r in group])
        if config != 'native':
            base = {r['run']: r for r in rows if r['workload'] == workload and r['configuration'] == 'native'}
            for metric, key in [('elapsed_seconds', 'paired_time_ratio'), ('max_rss_kib', 'paired_rss_ratio')]:
                item[key] = stats([r[metric] / base[r['run']][metric] for r in group])
        result.append(item)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--precheck-only', action='store_true')
    parser.add_argument('--verify', type=Path, help='Verify a saved record without running experiments')
    args = parser.parse_args()
    if args.verify:
        from verify_stage2 import verify
        print(json.dumps(verify(args.verify), indent=2))
        return
    lock = json.loads((ROOT / 'config/environment-lock.json').read_text(encoding='utf-8-sig'))
    cfg = json.loads((ROOT / 'config/stage2.json').read_text(encoding='utf-8-sig'))
    ident = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:6]
    out = ROOT / 'records/stage2' / ident
    out.mkdir(parents=True)
    print('STAGE 2 RECORD: ' + str(out), flush=True)
    commands, measurements = [], []
    started_utc = dt.datetime.now(dt.timezone.utc).isoformat()
    base = os.environ.copy()
    for k in ('ASAN_OPTIONS', 'LSAN_OPTIONS', 'UBSAN_OPTIONS', 'TSAN_OPTIONS'):
        base.pop(k, None)
    llvm_bin = subprocess.check_output(['llvm-config-14', '--bindir'], text=True).strip()
    base.update(PATH=llvm_bin + os.pathsep + base.get('PATH', ''), LC_ALL='C', TZ='UTC',
                OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                ASAN_SYMBOLIZER_PATH=llvm_bin + '/llvm-symbolizer')
    def env(config):
        options = '' if config == 'native' else lock['asan_default_options' if config == 'asan-modern' else 'asan_paper_like_options']
        return {**base, 'ASAN_OPTIONS': options}

    def run(argv, label, cwd=ROOT, environment=None, timeout=600, expected=0):
        prefix = out / label
        prefix.parent.mkdir(parents=True, exist_ok=True)
        stdout_path, stderr_path = Path(str(prefix) + '.stdout'), Path(str(prefix) + '.stderr')
        with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
            start = time.perf_counter()
            proc = subprocess.Popen([str(x) for x in argv], cwd=cwd, env=environment or base,
                                    stdout=stdout, stderr=stderr, start_new_session=True)
            timed_out = False
            try:
                code = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
                code = 124
            elapsed = time.perf_counter() - start
        row = {'argv': list(map(str, argv)), 'cwd': str(cwd), 'returncode': code,
               'elapsed_seconds': elapsed, 'timed_out': timed_out,
               'stdout': stdout_path.relative_to(out).as_posix(),
               'stderr': stderr_path.relative_to(out).as_posix()}
        commands.append(row)
        dump(out / 'commands.json', commands)
        if timed_out or (expected is not None and code != expected):
            raise RuntimeError(f'{label}: returncode={code}, timeout={timed_out}; inspect raw streams')
        return row

    def manifest():
        dump(out / 'sha256-manifest.json', {p.relative_to(out).as_posix(): sha(p)
             for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'sha256-manifest.json'})

    try:
        dump(out / 'status.json', {'passed': False, 'stage': 'precheck', 'started_utc': started_utc})
        assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == lock['benchmark_commit']
        run(['git', '-C', SOURCE, 'diff', '--exit-code'], 'environment/upstream-before')
        # Preserve the existing root/Olden selection, add only the approved subtrees.
        patterns = ['/*', '!/SingleSource/', '!/External/', '!/MicroBenchmarks/', '!/Fortran/',
                    '!/MultiSource/*', '/MultiSource/CMakeLists.txt', '/MultiSource/Benchmarks/CMakeLists.txt',
                    '/MultiSource/Benchmarks/Olden/']
        patterns += ['/' + x + '/' for x in cfg['new_subdirectories']]
        run(['git', '-C', SOURCE, 'sparse-checkout', 'set', '--no-cone', *patterns], 'environment/sparse-checkout')
        cpu = min(os.sched_getaffinity(0))
        dump(out / 'environment/affinity.json', {'cpu': cpu, 'allowed': sorted(os.sched_getaffinity(0)),
             'limitation': 'WSL virtual CPU to host P/E core mapping is uncontrolled.'})
        for name, argv in {
            'kernel': ['uname', '-a'], 'os': ['cat', '/etc/os-release'], 'cpu': ['lscpu'],
            'memory-before': ['free', '-h'], 'load-before': ['cat', '/proc/loadavg'],
            'disk': ['df', '-h', str(WORK)], 'compiler': ['clang-14', '--version'],
            'packages': ['dpkg-query', '-W'], 'cmake': ['cmake', '--version'],
            'lit': [WORK / 'venv/bin/lit', '--version'],
        }.items():
            run(argv, 'environment/' + name)
        power = ROOT / 'config/stage2-host-power.json'
        if power.exists():
            shutil.copyfile(power, out / 'environment/host-power.json')
        for folder in ('scripts', 'config', 'examples'):
            for file in (ROOT / folder).iterdir():
                if file.is_file():
                    target = out / 'source-snapshot' / folder / file.name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(file, target)

        buildroot = WORK / 'build/stage2'
        builds = {}
        names_by_size = {'ref': cfg['reference_names'], 'large': cfg['large_names']}
        for size in names_by_size:
            for variant in ('native', 'asan'):
                build = buildroot / (size + '-' + variant)
                build.mkdir(parents=True, exist_ok=True)
                subs = ['MultiSource/Benchmarks/Olden'] + (cfg['new_subdirectories'] if size == 'ref' else [])
                flags = lock['common_cflags'] + (' ' + lock['asan_cflags'] if variant == 'asan' else '')
                ldflags = lock['common_ldflags'] + (' -fsanitize=address' if variant == 'asan' else '')
                run(['cmake', '-G', 'Ninja', '-S', SOURCE, '-B', build,
                     '-DCMAKE_C_COMPILER=clang-14', '-DCMAKE_CXX_COMPILER=clang++-14',
                     '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_C_FLAGS_RELEASE=' + flags,
                     '-DCMAKE_CXX_FLAGS_RELEASE=' + flags, '-DCMAKE_EXE_LINKER_FLAGS=' + ldflags,
                     '-DTEST_SUITE_SUBDIRS=' + ';'.join(subs), '-DTEST_SUITE_RUN_TYPE=ref',
                     '-DTEST_SUITE_BENCHMARKING_ONLY=ON', '-DLARGE_PROBLEM_SIZE=' + ('ON' if size == 'large' else 'OFF')],
                     f'build/{size}-{variant}-configure')
                run(['cmake', '--build', build, '-j', '2'], f'build/{size}-{variant}-compile', timeout=1800)
                # Restore the omitted MultiSource parent contract in generated trees only.
                for sub in subs:
                    (build / sub / 'lit.local.cfg').write_text('config.traditional_output = True\n', encoding='utf-8')
                shutil.copyfile(build / 'CMakeCache.txt', out / 'build' / f'{size}-{variant}-CMakeCache.txt')
                builds[size, variant] = build

        workloads = {}
        for size, names in names_by_size.items():
            for name in names:
                files = list(builds[size, 'native'].rglob(name + '.test'))
                assert len(files) == 1, (name, files)
                test = files[0]
                relative = test.relative_to(builds[size, 'native'])
                original = test.read_text(encoding='utf-8')
                # All shell operators, including stdin redirection, remain intact.
                runlines = [line[4:].strip() for line in original.splitlines() if line.startswith('RUN:')]
                assert len(runlines) == 1, (test, runlines)
                assert not re.search(r'%(?!S\b)', runlines[0]), ('Unsupported lit substitution', runlines)
                ident_w = name + '-' + size
                dump(out / 'generated-tests' / (ident_w + '.json'), {'relative_path': relative.as_posix(), 'contents': original})
                item = {'name': name, 'size': size, 'test_relative': relative.as_posix(), 'run_template': runlines[0],
                        'commands': {}, 'binary_sha256': {}, 'reference_stdout_sha256': None}
                for config in CONFIGS:
                    build = builds[size, 'native' if config == 'native' else 'asan']
                    asan_test = build / relative
                    assert asan_test.read_text(encoding='utf-8') == original
                    folder = asan_test.parent
                    shell = runlines[0].replace('%S', shlex.quote(str(folder)))
                    item['commands'][config] = shell
                    item['binary_sha256'][config] = sha(folder / name)
                    # lit applies original VERIFY directives, including output hashing/fpcmp.
                    result_file = out / 'reference' / f'{ident_w}-{config}.json'
                    run([WORK / 'venv/bin/lit', '-v', '-j', '1', '--timeout', str(cfg['timeout_seconds']),
                         '-o', result_file, asan_test], f'reference/{ident_w}-{config}', cwd=build,
                        environment=env(config), timeout=cfg['timeout_seconds'] + 30)
                    reference = json.loads(result_file.read_text(encoding='utf-8'))
                    assert len(reference['tests']) == 1 and reference['tests'][0]['code'] == 'PASS', ident_w
                if size == 'large':
                    actual_args = shlex.split(runlines[0].split(';', 1)[1])[1:]
                    assert actual_args == cfg['large_arguments'][name], (name, actual_args)
                workloads[ident_w] = item
        tracked_files = subprocess.check_output(['git', '-C', str(SOURCE), 'ls-files', '-z'], text=False).split(b'\0')
        source_hashes = {}
        for raw in tracked_files:
            if raw:
                name = raw.decode('utf-8')
                p = SOURCE / name
                if p.is_file():
                    source_hashes[name] = sha(p)
        dump(out / 'environment/upstream-source-hashes.json', source_hashes)
        run(['git', '-C', SOURCE, 'diff', '--exit-code'], 'environment/upstream-after-build')

        demo = buildroot / 'memory_cases'
        run(['clang-14', '-O1', '-g', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie',
             '-fsanitize=address', ROOT / 'examples/memory_cases.c', '-o', demo], 'correctness/build')
        cases = {'heap': 'heap-buffer-overflow', 'stack': 'stack-buffer-overflow', 'global': 'global-buffer-overflow',
                 'uaf': 'heap-use-after-free', 'double_free': 'attempting double-free'}
        correctness = []
        for name, error in list(cases.items()) + [('control-' + x, None) for x in ('heap', 'stack', 'global', 'fixed')]:
            case = name.removeprefix('control-')
            index = ('8' if error else '7') if case in ('heap', 'stack', 'global') else ('8' if case == 'fixed' else '0')
            for i in range(1, 6):
                trial = run(['taskset', '-c', str(cpu), demo, case, index], f'correctness/{name}-{i:02d}',
                            environment=env('asan-modern'), expected=1 if error else 0)
                stderr = (out / trial['stderr']).read_text(encoding='utf-8', errors='replace')
                assert (error in stderr and re.search(r'memory_cases.c:\d+', stderr)) if error else 'ERROR: AddressSanitizer' not in stderr
                correctness.append({'case': name, 'run': i, 'expected_error': error, 'passed': True, **trial})
        dump(out / 'correctness.json', correctness)

        def measure(workload, config, index, phase):
            item = workloads[workload]
            timing = out / phase / workload / f'{config}-{index:02d}.time'
            timing.parent.mkdir(parents=True, exist_ok=True)
            # A fixed exec wrapper ensures the same time/taskset/shell overhead for all profiles.
            trial = run(['taskset', '-c', str(cpu), '/usr/bin/time', '-f',
                         'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmax_rss_kib=%M',
                         '-o', timing, 'bash', '-c', item['commands'][config]],
                        f'{phase}/{workload}/{config}-{index:02d}', environment=env(config), timeout=cfg['timeout_seconds'])
            metrics = {}
            for line in timing.read_text(encoding='utf-8').splitlines():
                k, v = line.split('=', 1)
                metrics[k] = float(v)
            stderr = (out / trial['stderr']).read_text(encoding='utf-8', errors='replace')
            assert not re.search(r'(ERROR|SUMMARY): (AddressSanitizer|LeakSanitizer)', stderr), workload
            actual_hash = sha(out / trial['stdout'])
            if item['reference_stdout_sha256'] is None:
                assert config == 'native' and phase == 'pilot'
                item['reference_stdout_sha256'] = actual_hash
            assert actual_hash == item['reference_stdout_sha256'], ('stdout differs', workload, config, phase, index)
            row = {'phase': phase, 'workload': workload, 'configuration': config, 'run': index,
                   'asan_options': env(config)['ASAN_OPTIONS'], 'stdout_sha256': actual_hash,
                   'time_log': timing.relative_to(out).as_posix(), **metrics, **trial}
            measurements.append(row)
            dump(out / 'measurements.json', measurements)
            print(f'{phase} {index:02d} {workload} {config}: {trial["elapsed_seconds"]:.4f}s', flush=True)

        for workload in workloads:
            for config in CONFIGS:
                measure(workload, config, 0, 'pilot')
        dump(out / 'workloads.json', workloads)
        frozen = {'stage': 2, 'started_utc': started_utc, 'frozen_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                  'lock': lock, **cfg, 'configurations': CONFIGS, 'workloads': list(workloads), 'chosen_cpu': cpu,
                  'timer': 'perf_counter includes taskset, GNU time, shell, process launch and exit',
                  'rss': 'GNU time peak resident set in KiB; not VmPeak',
                  'formal_trials': len(workloads) * len(CONFIGS) * cfg['runs'],
                  'pilot_policy': 'One fixed-work native and each ASan run before protocol freeze; excluded from statistics'}
        dump(out / 'protocol.json', frozen)
        if args.precheck_only:
            dump(out / 'status.json', {'passed': False, 'stage': 'precheck-complete', 'precheck_passed': True})
            manifest()
            print('STAGE 2 PRECHECK PASSED (no formal result): ' + str(out), flush=True)
            return
        for workload in workloads:
            for config in CONFIGS:
                for index in range(1, cfg['warmups'] + 1):
                    measure(workload, config, index, 'warmup')
        rng = random.Random(cfg['seed'])
        schedule = []
        for index in range(1, cfg['runs'] + 1):
            names = list(workloads)
            rng.shuffle(names)
            for workload in names:
                configs = list(CONFIGS)
                rng.shuffle(configs)
                schedule.extend({'workload': workload, 'configuration': c, 'run': index} for c in configs)
        dump(out / 'schedule.json', schedule)
        dump(out / 'status.json', {'passed': False, 'stage': 'measuring', 'formal_trials_expected': frozen['formal_trials']})
        for trial in schedule:
            measure(trial['workload'], trial['configuration'], trial['run'], 'performance')
        formal = [r for r in measurements if r['phase'] == 'performance']
        dump(out / 'summary.json', summarize(formal))
        fields = sorted(set().union(*(r.keys() for r in measurements)))
        with (out / 'measurements.csv').open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fields)
            writer.writeheader()
            writer.writerows(measurements)
        run(['cat', '/proc/loadavg'], 'environment/load-after')
        run(['free', '-h'], 'environment/memory-after')
        run(['git', '-C', SOURCE, 'diff', '--exit-code'], 'environment/upstream-final')
        dump(out / 'status.json', {'passed': True, 'stage': 'complete', 'formal_trials': len(formal),
             'correctness_trials': len(correctness), 'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat()})
        manifest()
        from verify_stage2 import verify
        print(json.dumps(verify(out), indent=2), flush=True)
        (ROOT / 'records/latest-stage2.txt').write_text(out.relative_to(ROOT).as_posix() + '\n', encoding='utf-8')
        print('STAGE 2 PASSED: ' + str(out), flush=True)
    except BaseException as error:
        dump(out / 'status.json', {'passed': False, 'stage': 'failed', 'error': repr(error),
             'formal_trials_saved': sum(r['phase'] == 'performance' for r in measurements),
             'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat()})
        manifest()
        raise


if __name__ == '__main__':
    main()
